﻿function close_on(){
	window.close();
}